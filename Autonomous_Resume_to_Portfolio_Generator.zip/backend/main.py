
from fastapi import FastAPI
import requests

app = FastAPI()

@app.get("/github/{username}")
def fetch_github(username: str):
    url = f"https://api.github.com/users/{username}/repos"
    repos = requests.get(url).json()

    projects = []
    for r in repos:
        projects.append({
            "name": r["name"],
            "description": r["description"],
            "language": r["language"]
        })

    return {"projects": projects}
