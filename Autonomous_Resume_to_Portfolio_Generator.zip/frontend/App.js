
import React, { useState } from "react";

function App() {
  const [username, setUsername] = useState("");
  const [projects, setProjects] = useState([]);

  const generatePortfolio = async () => {
    const res = await fetch(`http://localhost:8000/github/${username}`);
    const data = await res.json();
    setProjects(data.projects);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>AI Resume-to-Portfolio Generator</h2>
      <input
        placeholder="GitHub Username"
        onChange={(e) => setUsername(e.target.value)}
      />
      <button onClick={generatePortfolio}>Generate</button>

      {projects.map((p, i) => (
        <div key={i}>
          <h4>{p.name}</h4>
          <p>{p.description}</p>
          <p>{p.language}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
